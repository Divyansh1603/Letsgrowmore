# LGMVIP-Web-Development
 
Task-1- Single page website

Tech stacks used:

HTML   
CSS  
JAVASCRIPT  
BOOTSTRAP 

![image](https://user-images.githubusercontent.com/69354714/127664700-37779be2-1a95-40cd-a6c1-9a1cfeb9f938.png)
![image](https://user-images.githubusercontent.com/69354714/127661908-0370c97b-96f1-4a9a-a335-88bd7b662be6.png)
![image](https://user-images.githubusercontent.com/69354714/127662055-8fa507e8-01c4-49e0-895f-d6fde70d64d4.png)
![image](https://user-images.githubusercontent.com/69354714/127662183-63e37f8f-f249-4daa-a3ad-b542debff842.png)
![image](https://user-images.githubusercontent.com/69354714/127662248-32875cd8-87ce-4340-964e-4a672e68d717.png)
![image](https://user-images.githubusercontent.com/69354714/127662345-6c01d0ae-11c2-46e9-9714-ef6b0a591526.png)
![image](https://user-images.githubusercontent.com/69354714/127662424-38eae234-1cee-4610-8cfc-b72db6b9de26.png)
![image](https://user-images.githubusercontent.com/69354714/127662480-30811bfa-7078-4c24-8cbe-a5ce6ce28b86.png)

