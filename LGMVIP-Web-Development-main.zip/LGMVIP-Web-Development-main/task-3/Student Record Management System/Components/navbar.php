<div class="header">
    <div class="header-menu">
        <div class="sidebar-btn">
            <i class="fas fa-bars"></i>
        </div>
        <div class="title">STUDENT RECORDS <span>MANAGEMENT SYSTEM</span></div>
        <ul>
            <!-- <li><a href="Profile.php"><i class="fas fa-user"></i></a></li>
            <li><a href="#"><i class="fas fa-bell"></i></a></li> -->
            <li><a href="Components/logout.php"><i class="fas fa-sign-out-alt"></i></a></li>
        </ul>
    </div>
</div>